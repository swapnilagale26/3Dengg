<?php

// This file is part of the Certificate module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Handles uploading files
 *
 * @package    local_batch
 * @copyright  
 * @copyright 
 * @license    
 */
require_once('../../config.php');
require_once('lib.php');
require_once($CFG->libdir . '/formslib.php');
require_once('form/batch_form.php');
defined('MOODLE_INTERNAL') || die();
require_login();
$context = context_system::instance();
$contextid = $context->contextlevel;
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_url($CFG->wwwroot . '/local/batch/create_batch.php');
$title = get_string('pluginname', 'local_batch');
$local = get_string('local','local_batch');
$url = $CFG->wwwroot;
$mform  = '';
global $DB;


$PAGE->set_title($title);
$PAGE->set_heading($title);
$previewnode = $PAGE->navbar->add($local,$url);
$thingnode = $previewnode->add($title);
$thingnode->make_active();
$headingtext1 = get_string('create_batch','local_batch');
$heading = get_batch_heading($headingtext1,'','','');
$mform  =  new local_batch_form($CFG->wwwroot.'/local/batch/create_batch.php');

$data = $mform->get_data();
$returnurl = new moodle_url('/local/batch/list.php');
if($mform->is_cancelled()){
 	redirect($returnurl);
}
elseif($data){
	if(!empty($data)){
		$batch = insert_batch($data);
		$list_url = new moodle_url ('/local/batch/list.php',array('create'=>1));
		$redirect = redirect($list_url);
	}
}
echo $OUTPUT->header();
echo $heading;
echo '<hr>';
$mform->display();
echo $OUTPUT->footer();