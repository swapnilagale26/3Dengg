<?php

// This file is part of the Certificate module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Handles uploading files
 *
 * @package    local_batch
 * @copyright  
 * @copyright 
 * @license    
 */

if (!defined('MOODLE_INTERNAL')) 
{
    die('Direct access to this script is forbidden.'); /// It must be included from a Moodle page
}

require_once($CFG->libdir.'/formslib.php');
?>

<?php

class local_batch_form extends moodleform
{

	public function definition()
	{
		global $CFG,$OUTPUT,$DB,$USER,$PAGE;
		$context = context_system::instance();

		
		$mform = $this->_form;

		$mform->addElement('html', '<div class="container">');
			$mform->addElement('html', '<div class="row">');
				$mform->addElement('html', '<div class="col-md-6">');
					$center_choices = array();	
					$center_choices[0] = get_string('select_center','local_batch');
					$center_choices[1] = get_string('cent1','local_batch');
					$center_choices[2] = get_string('cent2','local_batch');
					$mform->addElement('select','center_name',get_string('center_name','local_batch'),$center_choices);
					$mform->settype('center_name', PARAM_RAW);
				$mform->addElement('html', '</div>');

				$mform->addElement('html', '<div class="col-md-6">');
					$mform->addElement('text','batch_code',get_string('batch_code','local_batch'));
					$mform->settype('batch_code', PARAM_RAW);
					$mform->addRule('batch_code',null,'required',null,'client');
				$mform->addElement('html', '</div>');
			$mform->addElement('html', '</div>');

			$mform->addElement('html', '<div class="row">');
				$mform->addElement('html', '<div class="col-md-6">');
					$mform->addElement('textarea','description',get_string('description','local_batch'), 'wrap="virtual" rows="3" cols="30"');
					$mform->settype('description', PARAM_RAW);
					$mform->addRule('description',null,'required',null,'client');
				$mform->addElement('html', '</div>');
				
				$mform->addElement('html', '<div class="col-md-6">');
					$status_array = [];
					$status_array[0] = get_string('select_status','local_batch');
					$status_array[1] = get_string('yettostart','local_batch');
					$status_array[2] = get_string('progress','local_batch');
					$status_array[3] = get_string('completed','local_batch');
					$mform->addElement('select','status',get_string('status','local_batch'),$status_array);
					$mform->settype('status', PARAM_RAW);
				$mform->addElement('html', '</div>');
			$mform->addElement('html', '</div>');

			$mform->addElement('html', '<div class="row">');
				$mform->addElement('html', '<div class="col-md-6">');
					$course_array = [];
					$course_array[0] = get_string('select_course','local_batch');
					$course_sql = "select * from {course}  where id!=1";
					$course = $DB->get_records_sql($course_sql);
					foreach($course as $val){
						$course_array[$val->id] = $val->fullname;
					}
					$mform->addElement('select','course_name',get_string('course_name','local_batch'),$course_array);
					$mform->settype('course_name', PARAM_RAW);
				$mform->addElement('html', '</div>');

				$mform->addElement('html', '<div class="col-md-6">');
					$mform->addElement('text','batch_capacity',get_string('batch_capacity','local_batch'));
					$mform->settype('batch_capacity', PARAM_RAW);
					$mform->addRule('batch_capacity',null,'required',null,'client');
				$mform->addElement('html', '</div>');
			$mform->addElement('html', '</div>');


			$mform->addElement('html', '<div class="row">');
				$mform->addElement('html', '<div class="col-md-6">');
					$mform->addElement('date_selector','start_date',get_string('start_date','local_batch'));
					$mform->settype('start_date', PARAM_RAW);
					$mform->addRule('start_date',null,'required',null,'client');
				$mform->addElement('html', '</div>');

				$mform->addElement('html', '<div class="col-md-6">');
					$mform->addElement('date_selector','end_date',get_string('end_date','local_batch'));
					$mform->settype('end_date', PARAM_RAW);
					$mform->addRule('end_date',null,'required',null,'client');
				$mform->addElement('html', '</div>');
			$mform->addElement('html', '</div>');


			$mform->addElement('html', '<div class="row">');
				$mform->addElement('html', '<div class="col-md-6">');
					$choices = array();	
					$choices[0] = get_string('select_type','local_batch');
					$choices[1] = get_string('stp','local_batch');
					$choices[2] = get_string('sttp','local_batch');
					$choices[3] = get_string('fdp','local_batch');
					$mform->addElement('select','batch_type',get_string('batch_type','local_batch'),$choices);
					$mform->settype('batch_type', PARAM_RAW);
				$mform->addElement('html', '</div>');

				$mform->addElement('html', '<div class="col-md-6">');
					$choices1 = array();	
					$choices1[0] = get_string('select_sem','local_batch');
					$choices1[get_string('one','local_batch')] = get_string('one','local_batch');
					$choices1[get_string('two','local_batch')] = get_string('two','local_batch');
					$choices1[get_string('three','local_batch')] = get_string('three','local_batch');
					$choices1[get_string('four','local_batch')] = get_string('four','local_batch');
					$choices1[get_string('five','local_batch')] = get_string('five','local_batch');
					$choices1[get_string('six','local_batch')] = get_string('six','local_batch');
					$choices1[get_string('seven','local_batch')] = get_string('seven','local_batch');
					$choices1[get_string('eight','local_batch')] = get_string('eight','local_batch');
					$mform->addElement('select','semester',get_string('semester','local_batch'),$choices1);
					$mform->settype('semester', PARAM_RAW);
					$mform->addRule('semester',null,'required',null,'client');
				$mform->addElement('html', '</div>');
			$mform->addElement('html', '</div>');

			$mform->addElement('html', '<div class="row">');
				$mform->addElement('html', '<div class="col-md-6">');
					$user_array = [];
					$user_array[0] = get_string('select_user','local_batch');
					$user_sql = "select * from {user} where id!=1&&id!=2";
					$users = $DB->get_records_sql($user_sql);
					foreach($users as $row){
						$user_array[$row->id] = $row->username;
					}
					$mform->addElement('select','select_trainer',get_string('select_trainer','local_batch'),$user_array);
					$mform->settype('select_trainer', PARAM_RAW);
				$mform->addElement('html', '</div>');

				$mform->addElement('html', '<div class="col-md-6">');
					
				$mform->addElement('html', '</div>');
			$mform->addElement('html', '</div>');
		$mform->addElement('html', '</div>');


		


		


		
		//action buttons start here//
		$buttonarray = array();
		$buttonarray[] = $mform->createElement('submit','submitbutton',get_string('savebutton','local_batch'));
		$buttonarray[] = $mform->createElement('cancel');

		$mform->addGroup($buttonarray,'buttonarray','','',false);
		//action buttons end here//
	}

	public function validation($data,$files)
	{	
		$errors = [];

		if($data['center_name'] == 0){
			
			$errors['center_name'] = get_string('error_center_name','local_batch');
		}
		if($data['status'] == 0){
			$errors['status'] = get_string('error_status','local_batch');
		}
		if($data['course_name'] == 0){
			$errors['course_name'] = get_string('error_course','local_batch');
		}
		if($data['batch_type'] == 0){
			$errors['batch_type'] = get_string('error_batch_type','local_batch');
		}
		if($data['select_trainer'] == 0){
			$errors['select_trainer'] = get_string('error_trainer','local_batch');
		}

		return $errors;
	}

}

?>
