<?php
// This file is part of the Local welcome plugin
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Handles uploading files
 *
 * @package    local_batch
 * @copyright  
 * @copyright  
 * @license    
 */


if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.'); // It must be included from a Moodle page.
}
global $CFG,$USER;




function insert_batch($data){
    // print_object($data);
    // exit;
    global $CFG,$USER,$DB;
    $insert_batch_object = new stdClass();
    $context = context_system::instance();
    $course_details = $DB->get_record('course',array('id'=>$data->course_name));
    $user_detail = $DB->get_record('user',array('id'=>$data->select_trainer));
    if($data->center_name == 1){
      $center_name = get_string('cent1','local_batch');
    }else{
      $center_name = get_string('cent2','local_batch');
    }

    if($data->status == 1){
      $status = get_string('yettostart','local_batch');
    }elseif($data->status == 2){
      $status = get_string('progress','local_batch');
    }else{
      $status = get_string('completed','local_batch');
    }

    if($data->batch_type == 1){
      $batch_type = get_string('stp','local_batch');
    }elseif($data->batch_type == 2){
      $batch_type = get_string('sttp','local_batch');
    }else{
      $batch_type = get_string('fdp','local_batch');
    }
    $insert_batch_object->center_name = $center_name;
    $insert_batch_object->batch_code = $data->batch_code;
    $insert_batch_object->description = $data->description;
    $insert_batch_object->status = $status;
    $insert_batch_object->course_name    = $course_details->fullname;
    $insert_batch_object->batch_capacity = $data->batch_capacity;
    $insert_batch_object->start_date = $data->start_date;
    $insert_batch_object->end_date = $data->end_date;
    $insert_batch_object->batch_type = $batch_type;
    $insert_batch_object->semester = $data->semester;
    $insert_batch_object->trainer_name = $user_detail->username;
    $insert_datas = $DB->insert_record('local_batch',$insert_batch_object);
    return $insert_datas;
}

function get_batch_heading($headingtext,$subheadingtext,$buttonlink,$buttontext){
    global $CFG;
    $headingdetails = html_writer::start_tag('div',  array('class' => 'row'));
    $headingdetails .= html_writer::start_tag('div',  array('class' => 'col-md-6'));
    $headingdetails .= html_writer::start_tag('h4');
    $headingdetails .= $headingtext;
    $headingdetails .= html_writer::end_tag('h4');
    $headingdetails .= html_writer::start_tag('p');
    $headingdetails .= $subheadingtext;
    $headingdetails .= html_writer::end_tag('p');
    $headingdetails .= html_writer::end_tag('div');
    $headingdetails .= html_writer::end_tag('div');
    return $headingdetails;
}

function list_batch_datas(){
    global $DB;
    $sql = 'SELECT * from {local_batch}';
    $getdetailes = $DB->get_records_sql($sql);
    return $getdetailes;
}

function create_batch_table($data){
    global $DB;
    $tabledisplay = '';
    $tabledisplay .= html_writer::start_tag('div',  array('class' => 'table table-bordered'));
    $table = new html_table();
    $table->head = (array) get_strings(array('sno','batch_code','cname','uname','center_name','batch_type','actionbtn'),'local_batch');
    $table->id =  'example';
    $i = 1;
    foreach ($data as $row) {
       $actiontbtn = create_batch_action_button($row->id);
      $table->data[] = array($i++,$row->batch_code,$row->course_name,$row->trainer_name,$row->center_name,$row->batch_type,$actiontbtn);
    }
    $tabledisplay .= html_writer::table($table);
    $tabledisplay .= html_writer::end_tag('div');

    return $tabledisplay;
}

function create_batch_action_button($data)
{
    global $CFG;
    $array = "";
    $array .= html_writer::start_tag('div',array('class'=>'dropdown menushow'));
    $array.=html_writer::start_tag('a',array('href' =>  '#','class'=>'btn btn-primary dropdown-toggle','role'=>"button", 'id'=>"dropdownMenuLink" ,'data-toggle'=>"dropdown", 'aria-haspopup'=>"true" ,'aria-expanded'=>"false"));
    $array .= get_string('actionbtn','local_batch');
    $array.=html_writer::end_tag('a');

    $array .= html_writer::start_tag('div', array('class' => 'dropdown-menu','aria-labelledby'=>"dropdownMenuLink"));

    $array .= html_writer::start_tag('a',array('href' =>'', 'class'=>"dropdown-item"));
    $array .= html_writer::start_tag('i',  array('class' => 'fa fa-edit iconspad'));
    $array .= html_writer::end_tag('i');
    $array .= get_string('edit','local_batch');
    $array .= html_writer::end_tag('a');


    $array .= html_writer::start_tag('a',array('href' => '', 'class'=>"dropdown-item"));
    $array .= html_writer::start_tag('i',  array('class' => 'fa fa-edit iconspad'));
    $array .= html_writer::end_tag('i');
    $array .= get_string('delete','local_batch');
    $array .= html_writer::end_tag('a');
    $array .= html_writer::end_tag('div');
    $array .= html_writer::end_tag('div');

    return $array;
}



