
<?php

// This file is part of the Certificate module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * Handles uploading files
 *
 * @package    local_batch
 * @copyright  
 * @copyright  
 * @license    
 */

require_once('../../config.php');
require_once('lib.php');
require_once($CFG->dirroot.'/local/batch/csslinks.php');
require_once($CFG->dirroot.'/local/batch/jslinks.php');
global $CFG,$PAGE,$OUTPUT,$USER;
require_login();
$create = optional_param('create','',PARAM_INT);
$context = context_system::instance();
$title = get_string('pluginname', 'local_batch');
$local = get_string('local','local_batch');
$url = $CFG->wwwroot;
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_title($title);
$PAGE->set_heading($title);
$previewnode = $PAGE->navbar->add($local,$url);
$thingnode = $previewnode->add($title);
$thingnode->make_active();
$PAGE->requires->jquery();
$PAGE->requires->js(new moodle_url($CFG->wwwroot . '/local/batch/script.js'));
$PAGE->set_url($CFG->wwwroot .'/local/batch/list.php');
$title = get_string('manage_datas','local_batch');
$PAGE->set_title($title);
echo $OUTPUT->header();
$list = list_batch_datas();
$table= create_batch_table($list);
echo $title;
echo '<hr>';
if(!empty($create))
{
	$sucssmsg = get_string('createscss','local_batch');
	echo $OUTPUT->notification($sucssmsg,'notifysuccess');
}
$link =  new moodle_url('/local/batch/create_batch.php');
$html = "";
$html .= html_writer::start_tag('a',array('role'=>'button','href'=>$link,'style'=>'float:right;margin-left:5px;','class'=>'btn btn-primary'));
$html .=get_string('create_batch','local_batch');
$html .= html_writer::end_tag('a');
echo $html;
echo "<br>";
echo "<br>";
 if(!empty($table)){
	echo $table;
}
echo $OUTPUT->footer();

