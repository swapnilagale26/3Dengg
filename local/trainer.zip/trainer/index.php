<?php

// This file is part of the Certificate module for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Handles uploading files
 *
 * @package    local_trainer
 * @copyright  Mallamma<mallamma@elearn10.com>
 * @copyright  Dhruv Infoline Pvt Ltd <lmsofindia.com>
 * @license    http://www.lmsofindia.com 2017 or later
 */
require_once('../../config.php');
global $DB,$CFG;
require_login();
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_pagelayout('admin');
$PAGE->set_url($CFG->wwwroot . '/local/trainer/index.php');
$PAGE->requires->jquery();
$title = get_string('pluginname', 'local_trainer');
$PAGE->set_title($title);
$PAGE->set_heading($title);
$PAGE->requires->js(new moodle_url($CFG->wwwroot.'/local/trainer/js/jquery.dataTables.min.js'),true);
$PAGE->requires->js(new moodle_url($CFG->wwwroot.'/local/trainer/js/dataTables.buttons.min.js'),true);
$PAGE->requires->js(new moodle_url($CFG->wwwroot.'/local/trainer/js/jszip.min.js'),true);
$PAGE->requires->js(new moodle_url($CFG->wwwroot.'/local/trainer/js/pdfmake.min.js'),true);
$PAGE->requires->js(new moodle_url($CFG->wwwroot.'/local/trainer/js/vfs_fonts.js'),true);
$PAGE->requires->js(new moodle_url($CFG->wwwroot.'/local/trainer/js/buttons.html5.min.js'),true);
$PAGE->requires->js(new moodle_url($CFG->wwwroot.'/local/trainer/js/buttons.print.min.js'),true);
$PAGE->requires->css(new moodle_url($CFG->wwwroot.'/local/trainer/css/buttons.dataTables.min.css'),true);
$PAGE->requires->css(new moodle_url($CFG->wwwroot.'/local/trainer/css/jquery.dataTables.min.css'),true);
echo $OUTPUT->header();
// if(!empty($records)){
    $report = new html_table();
    $report->id = "trainer";
    $report->head = array(get_string('serial','local_trainer'),
        get_string('centername','local_trainer'),
        get_string('trainername','local_trainer'),
        get_string('phoneno','local_trainer'),
        get_string('email','local_trainer'),
        get_string('status','local_trainer'));
//     $counter = 1;
//     foreach ($records as $record) {
//         $user = $DB->get_record('user',array('id'=>$record->userid));
//         $report->data[]=array(
//             $counter,
//             fullname($user),
//             $record->orderid,
//             $record->payment_status,
//             date($record->payment_date),
//             $record->packagename);
//     }
// }

//report table containing all the course userdetails.
$html='';
$html.=html_writer::start_div('container-fluid table-responsive');
$html.=html_writer::start_div('col-md-12');
$html.=html_writer::start_div('row');
$html.=html_writer::table($report);
$html.="<script>$(document).ready(function() {
$('#trainer').DataTable( {
  dom: 'Bfrtip',
  buttons: [
  'excel'
  ]
  } );
} );</script>";
$html.=html_writer::end_div();
$html.=html_writer::end_div();
$html.=html_writer::end_div();
echo $html;
echo $OUTPUT->footer();