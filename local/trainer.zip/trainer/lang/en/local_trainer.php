<?php
$string['pluginname']='Trainer';
$string['serial']='Sl#';
$string['centername']='Center Name';
$string['trainername']='Trainer Name';
$string['phoneno']='Phone No';
$string['email']='Email';
$string['status']='Status';
$string['coursename']='Course name';
$string['submit']='Submit';
$string['selectcourse']='Select Course';
$string['username']='Username';
$string['selectuser']='Select user';
$string['selectcourse']='Select course';
$string['trainerreport']='Trainer Report';
$string['create_trainer']='Create Trainer';
$string['selectcentre']='Select Center';